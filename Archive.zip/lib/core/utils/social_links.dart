abstract class SocialLinks {
  static const String facebook = "https://www.facebook.com/despicableapp";
  static const String x = "https://x.com/DespicableApp";
  static const String github = "https://github.com/mahidul-islam";
  static const String linkedin =
      "https://www.linkedin.com/company/despicableapp/";
}
